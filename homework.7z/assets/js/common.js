function showAside() {
	document.querySelector("aside").style.left = "0";
}

function hideAside() {
	document.querySelector("aside").style.left = "-300px";
}